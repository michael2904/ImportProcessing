package User;

import Controllers.GameController;


public class User {
	private GameController scenery;
	private Player player;
	int startingMoney = 300;
	int startingHealth = 100;
	
	public User(GameController screen){
		this.scenery = screen;
	}
	
	public void createPlayer (){
		//this.setPlayer(new Player (this));
	}

	public Player getPlayer() {
		return player;
	}

	public void setPlayer(Player player) {
		this.player = player;
	}

}
