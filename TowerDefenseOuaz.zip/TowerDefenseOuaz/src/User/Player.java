package User;


public class Player {
	private int health;
	private int money;
	private int points;
	
	public Player() {
		this.setMoney(100);
		this.setHealth(100);
		this.setPoints(0);		
	}

	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public int getMoney() {
		return money;
	}

	public void setMoney(int money) {
		this.money = money;
	}

	public int getPoints() {
		return points;
	}

	public void setPoints(int points) {
		this.points = points;
	}

}
