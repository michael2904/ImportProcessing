package Grids;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Scanner;

public class Maps {
	private static Scanner x;
	ArrayList<ArrayList<String>> Maps;
	ArrayList<String> MapsPos;

//constructor for the PlayerList object
	public Maps(String fileToParse) throws IOException{
		URL location = Maps.class.getProtectionDomain().getCodeSource().getLocation();
        System.out.println(location.getFile());
		Maps = new ArrayList<ArrayList<String>>();


        BufferedReader fileReader = null;
        
        //Delimiter used in CSV file
        final String DELIMITER = ",";
        try
        {
            String line = "";
            //Create the file reader
            fileReader = new BufferedReader(new FileReader(fileToParse));
            int i=0;

            //Read the file line by line
            while ((line = fileReader.readLine()) != null)
            {
            	MapsPos = new ArrayList<String>();

                //Get all tokens available in line
                String[] tokens = line.split(",");
                for(String token : tokens)
                {

                		MapsPos.add(token);
                }
                Maps.add(MapsPos);



            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        finally
        {
            try {
                fileReader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
	
	}
	

	public static void main(String[] args) {
	//use the try because an exception is thrown	
		try {
			Maps maps= new Maps("./MapsInfo.csv");
			//printList(maps.getMapsPos());
			System.out.println(maps.Maps);

		} catch (IOException e) {
			System.out.println("Could not find file.");
			}
	}
	
	
	public ArrayList<String> getMapsPos() {
		return MapsPos;
	}


	public void setMapsPos(ArrayList<String> mapsNames) {
		MapsPos = mapsNames;
	}


	public static void printList(ArrayList<String> maps){
		//loop to print a list
		for (int i=0; i < maps.size(); i++) {
			System.out.print(maps.get(i)+";");
		}
		System.out.println("end");
	}


	public void setWords(ArrayList<ArrayList<String>> maps) {
		Maps = maps;
	}


	public ArrayList<ArrayList<String>> getMaps() {
		return Maps;
	}
}

