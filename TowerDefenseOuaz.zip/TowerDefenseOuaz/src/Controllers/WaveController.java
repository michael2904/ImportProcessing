package Controllers;

import java.util.ArrayList;

import Models.Critter;
import Models.Ouaz;
import Models.Potato;
import Models.Toro;
import Models.Map;
import Models.PathCell;

public class WaveController {
	
	final static int MAX_AMOUNT_CRITTERS = 60;
	private ArrayList <Critter> wave;
	private Map map;
	private ArrayList <Integer> path;
	private int waveNumber = 0;
	private int numberOfWaves = 8;
	private double increaseFactor = 0.2;
	private int accumulator = 1;
	public WaveController(Map map, ArrayList<Integer> path){
		this.map = map;
		this.path = path;
		wave = new ArrayList<Critter>();
	}
	
	public void changeLevel(){
		iterateLevels(waveNumber);
		waveNumber++;
		if(waveNumber % numberOfWaves == 0)
			accumulator ++;
		waveNumber %= numberOfWaves;
		
	}
	
	private void iterateLevels(int index){
		switch(index){
		case 0:
			wave = wave0(map,path);
			break;
		case 1:
			wave = wave1(map,path);
			break;
		case 2:
			wave = wave2(map,path);
			break;
		case 3:
			wave = wave3(map,path);
			break;
		case 4:
			wave = wave4(map,path);
			break;
		case 5:
			wave = wave5(map,path);
			break;
		case 6:
			wave = wave6(map,path);
			break;
		case 7:
			wave = wave7(map,path);
			break;
		}
	}
	
	private ArrayList<Critter> wave0(Map map, ArrayList<Integer> path){
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 12; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			wave.add(ouaz);

		}
		return wave;
	}
	
	private ArrayList<Critter> wave1(Map map, ArrayList<Integer> path){
		wave.clear();
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 6; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			wave.add(ouaz);

		}
		return wave;
	}

	private ArrayList<Critter> wave2(Map map, ArrayList<Integer> path){
		wave.clear();
		int life;
		int damage;
		
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 4; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			damage = toro.getDamage();
			toro.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = toro.getLife();
			toro.setLife(life * accumulator);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			damage = ouaz.getDamage();
			ouaz.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = ouaz.getLife();
			ouaz.setLife(life * accumulator);
			wave.add(ouaz);
		}
		return wave;
	}
	
	private ArrayList<Critter> wave3(Map map, ArrayList<Integer> path){
		wave.clear();
		int damage;
		int life;
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 3; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			damage = toro.getDamage();
			toro.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = toro.getLife();
			toro.setLife(life * accumulator);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			damage = ouaz.getDamage();
			ouaz.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = ouaz.getLife();
			ouaz.setLife(life * accumulator);
			wave.add(ouaz);
		}
		return wave;
	}
	
	private ArrayList<Critter> wave4(Map map, ArrayList<Integer> path){
		wave.clear();
		int damage;
		int life; 
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 2; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			damage = toro.getDamage();
			toro.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = toro.getLife();
			toro.setLife(life * accumulator);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			damage = ouaz.getDamage();
			ouaz.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = ouaz.getLife();
			ouaz.setLife(life * accumulator);
			wave.add(ouaz);
		}
		return wave;
	}
	
	private ArrayList<Critter> wave5(Map map, ArrayList<Integer> path){
		wave.clear();
		int damage;
		int life;
		for(int i = 0; i < MAX_AMOUNT_CRITTERS / 1; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(3*i);
			damage = toro.getDamage();
			toro.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = toro.getLife();
			toro.setLife(life * accumulator);
			wave.add(toro);
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			damage = ouaz.getDamage();
			ouaz.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = ouaz.getLife();
			ouaz.setLife(life * accumulator);
			wave.add(ouaz);
		}
		return wave;
	}
	
	private ArrayList<Critter> wave6(Map map, ArrayList<Integer> path){
		wave.clear();
		int life;
		int damage;
		int mem = MAX_AMOUNT_CRITTERS / 6;
		for(int i = 0; i < mem; i++){
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(i);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator * 2);
			wave.add(potato);
		}
		
		for(int i = mem; i < mem + 5; i++){
			Toro toro = new Toro(map,path);
			toro.setIndexInArmy(i);
			damage = toro.getDamage();
			toro.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = toro.getLife();
			toro.setLife(life * accumulator + (int) (life * increaseFactor * accumulator));			
		}
		
		return wave;
	}
	
	private ArrayList<Critter> wave7(Map map, ArrayList<Integer> path){
		wave.clear();
		int life;
		int damage;
		
		int mem = MAX_AMOUNT_CRITTERS / 3;
		for(int i = 0; i < mem; i++){
			Potato potato = new Potato(map,path);
			potato.setIndexInArmy(3*i + 1);
			damage = potato.getDamage();
			potato.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = potato.getLife();
			potato.setLife(life * accumulator + (int) (life * increaseFactor * accumulator) * 2);
			wave.add(potato);
			Ouaz ouaz = new Ouaz(map,path);
			ouaz.setIndexInArmy(3 *i + 2);
			damage = ouaz.getDamage();
			ouaz.setDamage(damage + (int) (damage * increaseFactor * accumulator));
			life = ouaz.getLife();
			ouaz.setLife(life * accumulator + (int) (life * increaseFactor * accumulator) * 2);
			wave.add(ouaz);
		}
		return wave;
	}
	
	public ArrayList<Critter> getWave() {
		return wave;
	}

	public void setWave(ArrayList<Critter> wave) {
		this.wave = wave;
	}
}
