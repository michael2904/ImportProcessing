package Controllers;

import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextPane;

import Grids.Maps;

public class MainMenu {
	private JFrame frame;
	private JPanel menu;
	private GameController game;
	private boolean isPlaying;
	private JPanel chooseMap;
	private MainMenu menuback = this;
	private CreateMap createMap;
	private JComboBox comboBox;
	private MapsCombo combo;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainMenu window = new MainMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		frame.setResizable(false);
		menu = new JPanel();
		frame.getContentPane().add(menu, "name_23883563897428");
		menu.setBackground(Color.WHITE);
		frame.getContentPane().add(menu, "name_45805540063578");
		GridBagLayout gbl_menu = new GridBagLayout();
		gbl_menu.columnWidths = new int[]{0, 0};
		gbl_menu.rowHeights = new int[]{0, 0, 0, 0, 78, 246, 103, 0, 0};
		gbl_menu.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_menu.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, Double.MIN_VALUE};
		menu.setLayout(gbl_menu);
		
		JLabel lblMainMenu_1 = new JLabel("Main Menu");
		GridBagConstraints gbc_lblMainMenu_1 = new GridBagConstraints();
		gbc_lblMainMenu_1.insets = new Insets(0, 0, 5, 0);
		gbc_lblMainMenu_1.gridx = 0;
		gbc_lblMainMenu_1.gridy = 0;
		menu.add(lblMainMenu_1, gbc_lblMainMenu_1);
		
		JButton btnNewGame_1 = new JButton("New game");
		btnNewGame_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				menu.setVisible(false);
				game = new GameController(path(1), menuback);
				frame.getContentPane().add(game, "name_23883571019964");
				game.setVisible(true);
				game.play();
			}
		});
		GridBagConstraints gbc_btnNewGame_1 = new GridBagConstraints();
		gbc_btnNewGame_1.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewGame_1.gridx = 0;
		gbc_btnNewGame_1.gridy = 2;
		menu.add(btnNewGame_1, gbc_btnNewGame_1);
		
		JButton btnChooseMap = new JButton("Choose Map");
		btnChooseMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				menu.setVisible(false);
				chooseMap.setVisible(true);

			}
		});
		GridBagConstraints gbc_btnChooseMap = new GridBagConstraints();
		gbc_btnChooseMap.insets = new Insets(0, 0, 5, 0);
		gbc_btnChooseMap.gridx = 0;
		gbc_btnChooseMap.gridy = 3;
		menu.add(btnChooseMap, gbc_btnChooseMap);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(MainMenu.class.getResource("/Grids/Pokemon.jpg")));
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 0);
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 5;
		menu.add(lblNewLabel, gbc_lblNewLabel);
		
		JTextPane txtpnThisGameWas = new JTextPane();
		txtpnThisGameWas.setText("This game was programmed by:\n\n Eduardo Coronado-Montoya \n Sebastien Arrese \n Michael Abdallah-Minciotti");
		GridBagConstraints gbc_txtpnThisGameWas = new GridBagConstraints();
		gbc_txtpnThisGameWas.insets = new Insets(0, 0, 5, 0);
		gbc_txtpnThisGameWas.fill = GridBagConstraints.VERTICAL;
		gbc_txtpnThisGameWas.gridx = 0;
		gbc_txtpnThisGameWas.gridy = 6;
		menu.add(txtpnThisGameWas, gbc_txtpnThisGameWas);
		
		createMap = new CreateMap(this);
		JButton btnCreateMap = new JButton("Create Map");
		btnCreateMap.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				menu.setVisible(false);
				createMap.setVisible(true);
				createMap.create();
			}
			
		});
		GridBagConstraints gbc_btnCreateMap = new GridBagConstraints();
		gbc_btnCreateMap.insets = new Insets(0, 0, 5, 0);
		gbc_btnCreateMap.gridx = 0;
		gbc_btnCreateMap.gridy = 4;
		menu.add(btnCreateMap, gbc_btnCreateMap);
		frame.getContentPane().add(createMap,"name_72728499282739");
		
		JButton btnQuit = new JButton("Quit");
		btnQuit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		        System.exit(0);


			}
		});
		GridBagConstraints gbc_btnQuit = new GridBagConstraints();
		gbc_btnQuit.gridx = 0;
		gbc_btnQuit.gridy = 7;
		menu.add(btnQuit, gbc_btnQuit);
		
		chooseMap = new JPanel();
		frame.getContentPane().add(chooseMap, "name_43563640945544");
		chooseMap.setBackground(Color.WHITE);
		GridBagLayout gbl_chooseMap = new GridBagLayout();
		gbl_chooseMap.columnWidths = new int[]{300, 0};
		gbl_chooseMap.rowHeights = new int[]{0, 18, 0, 0, 0, 0,0, 349, 0};
		gbl_chooseMap.columnWeights = new double[]{1.0, Double.MIN_VALUE};
		gbl_chooseMap.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
		chooseMap.setLayout(gbl_chooseMap);
		
		JLabel lblChooseMap = new JLabel("Choose Map");
		lblChooseMap.setFont(new Font("Lucida Grande", Font.PLAIN, 24));
		GridBagConstraints gbc_lblChooseMap = new GridBagConstraints();
		gbc_lblChooseMap.insets = new Insets(0, 0, 5, 0);
		gbc_lblChooseMap.gridx = 0;
		gbc_lblChooseMap.gridy = 0;
		chooseMap.add(lblChooseMap, gbc_lblChooseMap);
		
		JButton btnMap1 = new JButton("Map 1");
		btnMap1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				game = new GameController(path(1), menuback);
				frame.getContentPane().add(game, "name_23883571019964");
				chooseMap.setVisible(false);
				game.setVisible(true);
				game.play();

			}
		});
		GridBagConstraints gbc_btnMap1 = new GridBagConstraints();
		gbc_btnMap1.insets = new Insets(0, 0, 5, 0);
		gbc_btnMap1.gridx = 0;
		gbc_btnMap1.gridy = 2;
		chooseMap.add(btnMap1, gbc_btnMap1);
		
		JButton btnMap2 = new JButton("Map 2");
		btnMap2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				game = new GameController(path(2), menuback);
				frame.getContentPane().add(game, "name_23883571019964");
				chooseMap.setVisible(false);
				game.setVisible(true);
				game.play();

			}
		});
		GridBagConstraints gbc_btnMap2 = new GridBagConstraints();
		gbc_btnMap2.insets = new Insets(0, 0, 5, 0);
		gbc_btnMap2.gridx = 0;
		gbc_btnMap2.gridy = 3;
		chooseMap.add(btnMap2, gbc_btnMap2);
		
		JButton btnMap3 = new JButton("Map 3");
		btnMap3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				game = new GameController(path(3), menuback);
				frame.getContentPane().add(game, "name_23883571019964");
				chooseMap.setVisible(false);
				game.setVisible(true);
				game.play();

			}
		});
		GridBagConstraints gbc_btnMap3 = new GridBagConstraints();
		gbc_btnMap3.insets = new Insets(0, 0, 5, 0);
		gbc_btnMap3.gridx = 0;
		gbc_btnMap3.gridy = 4;
		chooseMap.add(btnMap3, gbc_btnMap3);
		
		JLabel label = new JLabel("");
		label.setIcon(new ImageIcon(MainMenu.class.getResource("/Grids/PokemonBig.jpg")));
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.insets = new Insets(0, 0, 5, 0);
		gbc_label.gridx = 0;
		gbc_label.gridy = 7;
		chooseMap.add(label, gbc_label);
		
		JButton btnNewButton = new JButton("Quit");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chooseMap.setVisible(false);
				menu.setVisible(true);

			}
		});
		GridBagConstraints gbc_btnNewButton = new GridBagConstraints();
		gbc_btnNewButton.insets = new Insets(0, 0, 5, 0);
		gbc_btnNewButton.gridx = 0;
		gbc_btnNewButton.gridy = 8;
		chooseMap.add(btnNewButton, gbc_btnNewButton);
		
		Maps mapsnames = null;
		try {
			mapsnames = new Maps("./MapsInfo.csv");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<String> namesAr = new ArrayList<String>();
		for(ArrayList<String> names : mapsnames.getMaps()){
			namesAr.add(names.get(0));
		}
		
		MapsCombo combo = new MapsCombo(namesAr);
		
		comboBox = combo.getComboBox();
		GridBagConstraints gbc_btncomboBox = new GridBagConstraints();

		gbc_btncomboBox.insets = new Insets(0, 0, 5, 0);
		gbc_btncomboBox.gridx = 0;
		gbc_btncomboBox.gridy = 5;
		chooseMap.add(comboBox, gbc_btncomboBox);
		JButton btnchooseMap = new JButton("Play chosen map");
		btnchooseMap.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ArrayList<Integer> pathchosen = giveMap(comboBox.getSelectedItem().toString());
				game = new GameController(pathchosen, menuback);
				frame.getContentPane().add(game, "name_23883571019964");
				chooseMap.setVisible(false);
				game.setVisible(true);
				game.play();

			}
		});
		GridBagConstraints gbc_chooseMap = new GridBagConstraints();
		gbc_chooseMap.insets = new Insets(0, 0, 5, 0);
		gbc_chooseMap.gridx = 0;
		gbc_chooseMap.gridy = 6;
		chooseMap.add(btnchooseMap, gbc_chooseMap);


		frame.pack();
	}
	
	public void goBackToMenu(){
		menu.setVisible(true);
		game.setVisible(false);
		
	}
	public void goBackToMenuFromCreateMap(){
		menu.setVisible(true);
		createMap.setVisible(false);
		
	}

	public ArrayList<Integer> giveMap(String name){
		Maps mapspath = null;
		try {
			mapspath = new Maps("./MapsInfo.csv");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ArrayList<String> paths = null;
		System.out.println(mapspath.getMaps());

		for(ArrayList<String> names : mapspath.getMaps()){
			if(names.get(0).equals(name)){
				paths = names;
				System.out.println(paths);

			}
		}
		System.out.println(paths);
		paths.remove(0);
		System.out.println(paths);
		ArrayList<Integer> numbers = new ArrayList<Integer>();

		for(int i = 0; i < paths.size(); i++) {
			   numbers.add(Integer.parseInt(paths.get(i)));   
			}
		return numbers;
		
	}
	
	public ArrayList<Integer> path(int n){
		int [][] path = {{13,14,2,3,4,5,6,18,30,31,32,33,34,46,58,70,69,68,67,66,65,64,63,75,87,99,111,110,109},{13,25,26,27,39,51,52,53,54,55,67,79,91,90,89,88,100,112,124,125,126,127,128,129,130,131,132},{13,14,15,16,17,18,19,31,43,55,54,53,52,51,63,75,76,77,78,79,91,92,93,81,69,57,45,33,34,35,36}};
		ArrayList<Integer> temp = new ArrayList<Integer>();
		
		for(int i = 0; i < path[n-1].length; i++){
			temp.add(path[n-1][i]);
		}
		return temp;
	}
	
	public void playCustomedMap(ArrayList<Integer> path, int height, int width, 
			int numCols, int numRows){
		game = new GameController(path, menuback, height, width, numCols, numRows);
		frame.getContentPane().add(game, "name_23883571019964");
		createMap.setVisible(false);
		game.setVisible(true);
		game.play();
	}

	public JComboBox getComboBox() {
		return comboBox;
	}

	public void setComboBox(JComboBox comboBox) {
		this.comboBox = comboBox;
	}

	public MapsCombo getCombo() {
		return combo;
	}

	public void setCombo(MapsCombo combo) {
		this.combo = combo;
	}

}