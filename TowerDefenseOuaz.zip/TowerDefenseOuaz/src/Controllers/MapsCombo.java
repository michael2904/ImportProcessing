package Controllers;

import java.awt.BorderLayout;
import java.awt.Container;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Vector;

import javax.swing.AbstractListModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.MutableComboBoxModel;

public class MapsCombo extends AbstractListModel implements
MutableComboBoxModel {
private Object selectedItem;
private MapsCombo model;

private ArrayList anArrayList;

public MapsCombo(ArrayList arrayList) {
anArrayList = arrayList;
}
Vector objects = new Vector();
Object item;
public void addElement( Object ob )
{
  objects.addElement( ob );
}
public void insertElementAt( Object ob, int index )
{
  objects.add( index, ob );
}
public void removeElement( Object ob )
{
  objects.removeElement( ob );
}
public void removeElementAt( int index )
{
  objects.removeElementAt( index );
}

public Object getSelectedItem() {
return selectedItem;
}

public void setSelectedItem(Object newValue) {
selectedItem = newValue;
}

public int getSize() {
return anArrayList.size();
}

public Object getElementAt(int i) {
return anArrayList.get(i);
}

public static void main(String args[]) {
JFrame frame = new JFrame("ArrayListComboBoxModel");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

Collection col = System.getProperties().values();
ArrayList arrayList = new ArrayList(col);
MapsCombo model = new MapsCombo(arrayList);

JComboBox comboBox = new JComboBox(model);

}
public JComboBox getComboBox(){
	MapsCombo model = new MapsCombo(anArrayList);

	JComboBox comboBox = new JComboBox(model);
	return comboBox;
	
}

public MapsCombo getModel() {
	return model;
}

public void setModel(MapsCombo model) {
	this.model = model;
}
}