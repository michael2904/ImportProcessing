package Controllers;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Models.Critter.CritterType;
import Models.Cell;
import Models.Critter;
import Models.Map;
import Models.PathCell;
import Models.Pokemons;
import Models.SceneryCell;
import Models.Tower;
import User.Player;

public class GameController extends JPanel implements MouseMotionListener, MouseListener{

	private Graphics2D g2d;
	private int [] xCoordsPath;
	private int [] yCoordsPath;
	private ArrayList<Integer> path = new ArrayList<Integer>();
	private boolean isPaused = false;
	private boolean hasLost = false;
	private boolean towerClicked = false;
	private boolean wantsToQuit = false;
	public Rectangle[]towerButton= new Rectangle[50];

	private boolean isOutOfMap = false;
	public CritterController army;
	private ArrayList<Tower> towers = new ArrayList<Tower>();
	private Map map;
	boolean mouseDown=false;
	public int hand=0;
	public int handXpos;
	public int handYpos;
	public int scene=1;
	private int xMap;
	private int yMap;
	
	private int ColAmountMap;
	private int RowAmountMap;
	private int ColSizeMap;
	private int RowSizeMap;
	private int HeightMap;
	private int WidthMap;
	
	private WaveController waves;
	private Player player;
	private Pokemons pokemons;
	private int indexInTowerList;
	private int towerToBeDrawn;
	private MainMenu menu;
	Image sceneryGrass = new ImageIcon("res/grass.jpg").getImage();
	Image pathGrass = new ImageIcon("res/pathgrass.jpg").getImage();
	private TowerController tc;
	
	public int getRowSizeMap(){
		return RowSizeMap;
	}
	
	public int getColSizeMap(){
		return ColSizeMap;
	}
	public GameController(ArrayList<Integer> path, MainMenu menu){
		this.ColAmountMap = Global.COL_AMOUNT;
		this.RowAmountMap = Global.ROW_AMOUNT;
		this.HeightMap = Global.HEIGHT;
		this.WidthMap = Global.WIDTH;
		this.ColSizeMap = Global.COL_SIZE;
		this.RowSizeMap = Global.ROW_SIZE;
		this.menu = menu;
		this.path = path;
		setPreferredSize(new Dimension(WidthMap + 200, HeightMap));
		player = new Player();
		pokemons = new Pokemons(this);
		setLayout(null);
		setScoreBoard();
		instantiateTowerButtons();

		xCoordsPath = new int[path.size()];
		yCoordsPath = new int[path.size()];
		drawPath(path);

		this.map = new Map(RowAmountMap, ColAmountMap, 
				RowSizeMap, ColSizeMap, setMapPathCells());
		this.waves = new WaveController(map,path);
		this.setVisible(true);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
	}
	
	public GameController(ArrayList<Integer> path, MainMenu menu, int height, int width,
			int numCols, int numRows){
		this.ColAmountMap = numCols;
		this.RowAmountMap = numRows;
		this.HeightMap = height;
		this.WidthMap = width;
		this.ColSizeMap = width/ColAmountMap;
		this.RowSizeMap = height/RowAmountMap;
		this.menu = menu;
		this.path = path;
		setPreferredSize(new Dimension(WidthMap + 200, HeightMap));
		player = new Player();
		pokemons = new Pokemons(this);
		setLayout(null);
		setScoreBoard();
		instantiateTowerButtons();

		xCoordsPath = new int[path.size()];
		yCoordsPath = new int[path.size()];
		drawPath(path);
		
		this.map = new Map(RowAmountMap, ColAmountMap, 
				RowSizeMap, ColSizeMap, setMapPathCells());
		this.waves = new WaveController(map,path);
		this.setVisible(true);
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		
		System.out.println("xSIZE: " + ColSizeMap + "ySIZE: " + RowSizeMap);
	}
	
	public ArrayList<PathCell> setMapPathCells() {
		ArrayList<PathCell> temp = new ArrayList<PathCell>();
		for (int i = 0; i < path.size(); i++) {
			int tempID = path.get(i);
			int tempX = (tempID - 1) % ColAmountMap * ColSizeMap;
			int tempY = (tempID - 1) / ColAmountMap * RowSizeMap;
			temp.add(new PathCell(tempID,tempX,tempY));
		}
		return temp;
	}
	
	private void setWave(){
		if(army == null){
			waves.changeLevel();
			army = new CritterController(waves.getWave(), map);
			//this.army.setSwitch(path.get(0), path.get(1));
		} else if(army.getLength() == 0){
			waves.changeLevel();
			army = new CritterController(waves.getWave(), map);
			//this.army.setSwitch(path.get(0), path.get(1));
		}
	}
	
	private void restart(){
		if(isPaused){
			army = null;
			towers = null;
			waves = new WaveController(map,path);
			setWave();
			isPaused = false;
		}
	}
	
	public void paintComponent(Graphics g){
		if(!hasLost){
			if (!isPaused) {
				update();
			}
			// Grid Layout
			setGrid(g);
			// Mouse Color
			setColorToMouse(g);
			// Path Color
			setColorToPath(g);
			// Score Panel
			drawGrass(g);
			setScore(g);
			// Store Panel
			if(!towerClicked)
				setStore(g);
			else 
				setUpgradeTower(g);
			if(army!=null)
			for (int i = 0; i < army.getLength(); i++) {
				setColorToCritter(g, i);
			}

			drawTowers(g);
			if(army!= null){
				drawProjectiles(g);
			}
			drawTowerOnMouse(g);
		} else {
			g.setColor(Color.WHITE);
			g.fillRect(0, 0, WidthMap, HeightMap);
			g.setColor(Color.BLACK);
			g.drawString("YOU LOST!", WidthMap/2, HeightMap/2);
		}
	}
	
	public void setUpgradeTower(Graphics g){

		g.setColor(Color.WHITE);
		g.fillRect(WidthMap, 0, 200, HeightMap / 2);

		g.setColor(Color.CYAN);
		g.fill3DRect(WidthMap + 50, 240, 100, 30, true);
		g.fill3DRect(WidthMap + 50, 200, 100, 30, true);
		
		g.setColor(Color.BLACK);
		g.drawString("Back", WidthMap + 75, 260);
		g.drawString("Remove", WidthMap + 75, 220);
		
		upgradeTower();
		if(towerToBeDrawn == -1){
			return;
		}
		Tower toDraw = pokemons.getPokemons()[towerToBeDrawn];
		if (toDraw.cost> player.getMoney()){ //player money
			g.drawImage(toDraw.texture, 50 + WidthMap, 25,
					50, 50, null);
			g.setColor(new Color(255,0,0,100));
			g.fillRect(50 + WidthMap,25,50,50);
		} else {
			g.setColor(Color.CYAN);
			g.fill3DRect(WidthMap + 50, 160, 100, 30, true);
			g.setColor(Color.BLACK);
			g.drawString("Upgrade", WidthMap + 75, 180);
			
			g.drawImage(toDraw.texture, 50 + WidthMap, 25,
					50, 50, null);
		}
		isPaused = true;
	}
	
	public void drawProjectiles(Graphics g){
		g2d = (Graphics2D) g;
		g2d.setColor(Color.BLACK);
		for(int i = 0 ; i < towers.size(); i++){
			Tower tower = towers.get(i);
			if(tower.getTarget() != null){
				if(army.getxCritters().size() == 0){
					continue;
				} if (army.getxCritters().size() <= tower.target.getIndexInArmy()){
					continue;
				}
				try{
				g2d.drawLine(
						tower.getxCoord(),
						tower.getyCoord(),
						army.getxCritters().get(
								(tower.getTarget().getIndexInArmy()))
								+ Global.OFFSET,
						army.getyCritters().get(
								(tower.getTarget().getIndexInArmy()))
								+ Global.OFFSET);
				} catch (NullPointerException e){
					System.out.println("Index In Army :" + tower.getTarget().getIndexInArmy());
					System.out.println("Army SIZE: " + army.getxCritters().size());
				}
			}
		}
	}
	
	public void drawGrass(Graphics g){
		for(int i = 0; i < map.getLength(); i++){
			for(int j = 0; j< map.getHeight(); j++){
				Cell cell = map.getContainer()[j][i];
				if(cell.getCellType() == Cell.CellType.SCENERY){
					g.drawImage(sceneryGrass, i*ColSizeMap + 1,
							j*RowSizeMap + 1, ColSizeMap - 2,
							RowSizeMap - 2, null);
				} else {
					g.drawImage(pathGrass, i*ColSizeMap + 1,
							j*RowSizeMap + 1, ColSizeMap - 2,
							RowSizeMap - 2, null);
				
				}
			}
		}
	}
	
	public void drawTowerOnMouse(Graphics g){
		if (this.handXpos < WidthMap - ColSizeMap/2 + 3) {
			if (hand != 0 && pokemons.getPokemons()[hand - 1] != null) {
				g.drawImage(pokemons.getPokemons()[hand - 1].texture,
						this.handXpos - 50 / 2, this.handYpos - 50 / 2, 50, 50,
						null);
			}
		}
	}
	
	public void drawTowers(Graphics g) {
		for (int i = 0; i < towers.size(); i++) {
			Tower tower = towers.get(i);
			g.drawImage(pokemons.getPokemons()[tower.id].texture,
					(tower.getPosX() * ColSizeMap) + 1,
					(tower.getPosY() * RowSizeMap) + 1, ColSizeMap - 1,
					RowSizeMap - 1, null);
			
		}
	}

	public void setColorToMouse(Graphics g){
		if(!isOutOfMap){
			g.setColor(Color.YELLOW);
			g.fillRect(xMap + 1, yMap + 1, ColSizeMap - 1, RowSizeMap - 1);
		}
	}
	
	public void setColorToCritter(Graphics g, int i) {

		if (!army.getCritterInArmy(i).hasReachedLastCell()) {
			if (army.getCritterInArmy(i).getType() == CritterType.OUAZ) {
				g.setColor(Color.LIGHT_GRAY);
			} else if (army.getCritterInArmy(i).getType() == CritterType.POTATO) {
				g.setColor(Color.BLUE);
			} else {
				g.setColor(Color.GREEN);
			}
			
			g.fillRect(army.getxCritters().get(i), army.getyCritters().get(i),
					2 * Global.OFFSET, 2 * Global.OFFSET);
		} else {
			int health = player.getHealth();
			player.setHealth(health - army.getCritterInArmy(i).getDamage());
			army.removeDeadCritters(i);
		}
	}
	
	public void play(){
		try{
			gameThread();
		} catch (Exception e){
			
		}
	}
	public void setScoreBoard(){
		
		JButton startNewWave = new JButton("Start New Wave");
		startNewWave.setBounds(WidthMap + 40, 73 + HeightMap/2, 140,30);
		startNewWave.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(army == null){
					setWave();
				} else if(army.getLength() == 0){
					setWave();
				}
			}
			
		});
		this.add(startNewWave);
		
		JButton pauseGame = new JButton("Pause");
		pauseGame.setBounds(40 + WidthMap, 113 + HeightMap/2, 100, 30);
		pauseGame.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				JButton button = (JButton)arg0.getSource();

				if(!isPaused){
					button.setText("Resume");
					isPaused = true;
				} else {
					button.setText("Pause");
					isPaused = false;
				}
			}
		});
		this.add(pauseGame);

		JButton restart = new JButton("Restart");
		restart.setBounds(40 + WidthMap, 153 + HeightMap/2, 100, 30);
		restart.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				restart();
			}
			
		});
		this.add(restart);

		JButton save = new JButton("Save");
		save.setBounds(40 + WidthMap, 193+ HeightMap/2, 100, 30);
		this.add(save);

		JButton quit = new JButton("Quit");
		quit.setBounds(40 + WidthMap, 233 + HeightMap/2, 100, 30);
		quit.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				wantsToQuit = true;
				menu.goBackToMenu();
			}
			
		});
		this.add(quit);
	}

	public void setStore(Graphics g){
		g.setColor(Color.WHITE);
		g.fillRect(WidthMap, 0, 200, HeightMap/2);
		g.setColor(Color.BLACK);
		for (int i= 0; i<3; i++){
			g.drawRect(50 + WidthMap,25+50*i,50,50);
			if( pokemons.getPokemons()[i] != null){
				g.drawImage(pokemons.getPokemons()[i].texture,50 + WidthMap, 25+50*i, 50,50, null);
				if (pokemons.getPokemons()[i].cost> player.getMoney()){ //player money
					g.setColor(new Color(255,0,0,100));
					g.fillRect(50 + WidthMap,25+50*i,50,50);
				}
			}
			g.setColor(Color.BLACK);

		}

		g.setFont(new Font("Arial", Font.PLAIN, 16)); 
		g.drawString("Towers", 50 + WidthMap, 16);
		g.setFont(new Font("Arial", Font.PLAIN, 14)); 
		g.drawString("Bulbasaur", 110 + WidthMap, 50);
		g.drawString("Squirtle", 110 + WidthMap, 100);
		g.drawString("Charmender", 110 + WidthMap, 150);

	}

	public void setGrid(Graphics g) {
		g2d = (Graphics2D) g;

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, WidthMap, HeightMap);

		g.setColor(Color.BLACK);
		for (int i = 0; i <= RowAmountMap; i++) {
			if(i == RowAmountMap){
				g2d.drawLine(0, i * RowSizeMap - 1, WidthMap - 1, i * RowSizeMap - 1);
				continue;
			}
			g2d.drawLine(0, i * RowSizeMap, WidthMap-1, i * RowSizeMap);
		}
		for (int i = 0; i <= ColAmountMap; i++) {
			g2d.drawLine(i * ColSizeMap, 0, i * ColSizeMap, HeightMap);
		}

	}

	public void setColorToPath(Graphics g) {
		g.setColor(Color.CYAN);
		for (int i = 0; i < path.size(); i++) {
			g.fillRect(xCoordsPath[i] + 1, yCoordsPath[i] + 1, ColSizeMap - 1,
					RowSizeMap - 1);
		}
		g.setColor(Color.RED);

	}

	public void setScore(Graphics g){
		g.setColor(Color.WHITE);
		g.fillRect(WidthMap, HeightMap/2, 200, HeightMap/2);
		g.setColor(Color.BLACK);
		g.setFont(new Font("Arial", Font.PLAIN, 14)); 
		g.drawString("Health: " + player.getHealth(), 20 + WidthMap, 20 + HeightMap/2);
		g.drawString("Points: " + player.getPoints(), 20 + WidthMap,40 + HeightMap/2);
		g.drawString("Money: " + player.getMoney() + "$", 20 + WidthMap, 60 + HeightMap/2);
	}

	public void drawPath(ArrayList<Integer> ids) {
		int size = ids.size();

		for (int i = 0; i < size; i++) {
			xCoordsPath[i] = ((ids.get(i) - 1) % ColAmountMap) * ColSizeMap;
			yCoordsPath[i] = ((ids.get(i) - 1) / ColAmountMap) * RowSizeMap;
		}
	}

	private void instantiateTowerButtons() {
		for (int i= 0; i<3; i++){
			towerButton[i] = new Rectangle(50, 25+50*i,50,50);
		}

	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent e) {
		getCellXY(e);
		this.handXpos = e.getX();
		this.handYpos = e.getY();
	}
	
	public void getCellXY(MouseEvent e) {
		int mouseCell = getMouseCell(e) - 1;
		xMap = (mouseCell % ColAmountMap) * ColSizeMap;
		yMap = (mouseCell / ColAmountMap) * RowSizeMap;
	}

	private int getMouseCell(MouseEvent e) {
		int currentX = e.getX();
		int currentY = e.getY();

		if(currentX >= WidthMap) 
			isOutOfMap = true;
		else 
			isOutOfMap = false;

		int tileCol = currentX / ColSizeMap;
		int tileRow = currentY / RowSizeMap;

		return tileRow * ColAmountMap + tileCol + 1;
	}
	
	public void updateMouse(MouseEvent e){
		if (scene == 1){
			if(mouseDown && hand == 0){
				if(e.getX()>= 650 && e.getX()<=700){
					if(e.getY()>=30 && e.getY()<=180){
						//Tower 1
						if(e.getY()>=30 && e.getY()<=80 
								&& e.getX()>= 650 && e.getX()<=700){
							if(player.getMoney() >= pokemons.getPokemons()[0].cost){ //user money
								//System.out.println("You Bought Machine Gun Tower");
								hand =1;
							}
						}
						//Tower 2
						else if(e.getY()>=80 && e.getY()<=130 
								&& e.getX()>= 650 && e.getX()<=700){
							if(player.getMoney() >= pokemons.getPokemons()[1].cost){ //user money
								//System.out.println("You Bought Missile Tower");
								hand =2;
							}
						}

						//Tower 3
						else if(e.getY()>=130 && e.getY()<=180 
								&& e.getX()>= 650 && e.getX()<=700){
							if(player.getMoney() >= pokemons.getPokemons()[2].cost){ //user money
								//System.out.println("You Bought ShotGun Tower");
								hand =3;
							}
						}
					}
				}
			}
		}
	}
	
	public void mouseDown(MouseEvent e){
		
		mouseDown = true;
		
		if(hand != 0){
			placeTower(e.getX(),e.getY());
			mouseDown = false;
			hand = 0;
		}
		updateMouse(e);
	
	}
	
	private void upgradeTower(){
		if(towers.size() != 0){
			Tower tower = towers.get(indexInTowerList);
			int level = tower.getLevel();
			int id = tower.getId();
			if (level == 3) {
				towerToBeDrawn = -1;
				return;
			}
			towerToBeDrawn = id + 3;
		}
	}
	
	private void changeTower(){
		int currIndex = indexInTowerList;
		if(towerToBeDrawn == -1) return;
		if(towerToBeDrawn > 8) towerToBeDrawn -= 3;
		
		Tower tower = towers.get(currIndex);
		Tower clone = (Tower) pokemons.getPokemons()[towerToBeDrawn].clone();
		clone.setIndexInList(currIndex);
		
		int money = player.getMoney();
		player.setMoney(money - clone.getCost());
		clone.setPosX(tower.getPosX());
		clone.setPosY(tower.getPosY());
		
		towers.add(currIndex,clone);
		towers.remove(currIndex + 1);
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		int x = xMap/ColSizeMap;
		int y = yMap/RowSizeMap;
		
		if(map.getContainer()[y][x].getCellType() == Cell.CellType.SCENERY){
			SceneryCell cell = (SceneryCell) map.getContainer()[y][x];
			
			if(cell.hasTower() && mouseDown){
				towerClicked = true;
				getTowerClicked(cell);
			}
		}
		if(handXpos <= WidthMap + 150 && handXpos >= WidthMap + 50){
			if(handYpos <= 190 && handYpos >= 160){
				Tower toDraw = pokemons.getPokemons()[towerToBeDrawn];
				if (toDraw.getCost() < player.getMoney()) {
					 changeTower();
				}
			} else if (handYpos <= 230 && handYpos >= 200) {
				removeTower();
			} else if (handYpos <= 270 && handYpos >= 240) {
				towerClicked = false;
				isPaused = false;
			}
		}
	}
	
	private void removeTower(){
		Tower tower = towers.get(indexInTowerList);
		map.removeTower(tower.getPosY(), tower.getPosX());
		towerClicked = true;
		isPaused = false;
		int money = player.getMoney();
		player.setMoney(money + tower.getRefundValue());
		towers.remove(indexInTowerList);
		for(int i = 0; i < towers.size(); i++){
			tower = towers.get(i);
			tower.setIndexInList(i);
		}
		if(towers.size() != 0 && indexInTowerList != 0) indexInTowerList --;
	}
	
	private void getTowerClicked(SceneryCell cell){
		for(int i = 0; i < towers.size(); i++){
			if(cell.getRow() == towers.get(i).getPosY() && 
					cell.getCol() == towers.get(i).getPosX()){
				indexInTowerList = i;
			}
		}
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		if(!towerClicked) mouseDown(e);
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	protected void gameThread(){
		Thread thread = new Thread(new Runnable(){
			@Override
			public void run() {
				while(!wantsToQuit){
					invalidate();
					repaint();
				}
			}
		});
		thread.start();
	}
	
	public void placeTower(int x, int y){
		
		if(xMap < WidthMap){
			
			int xPos= x/ColSizeMap; //tower width
			int yPos = y/RowSizeMap; //tower HeightMap
			//check if square is occupied && else if must be added
			SceneryCell cell = (SceneryCell) map.getContainer()[yPos][xPos];
			if (!cell.hasTower()){ 
				Tower clone = (Tower) pokemons.getPokemons()[hand-1].clone();
				clone.setIndexInList(towers.size());
				int money = player.getMoney();
				player.setMoney(money - pokemons.getPokemons()[hand-1].getCost());
				map.addTower(yPos, xPos);
				System.out.println("xPos: " + xPos + "yPos: " + yPos);
				clone.setPosX(xPos);
				clone.setPosY(yPos);
				towers.add(clone);
			}
		}
	}

	public void update(){
		armyUpdate();
		towerUpdate();
		gameUpdate();
	}
	
	public void gameUpdate(){
		if(player.getHealth() <= 0){
			hasLost = true;
		}
	}
	
	public void armyUpdate(){
		if(army != null){
		for(int i = 0; i < army.getLength(); i++){
			if(army.getCritterInArmy(i).getLife() <= 0){
				int money = player.getMoney();
				player.setMoney(money + army.getCritterInArmy(i).getMoneyReward());
				int points = player.getPoints();
				player.setPoints(points + army.getCritterInArmy(i).getPointReward());
				army.removeDeadCritters(i);
			}
		}		
		}
	}
	
	private int counterEnemy = 0;
	private int LIMIT = 40;
	
	public void towerUpdate(){
		for(int i = 0; i < towers.size(); i++){
			Tower tower = towers.get(i);
			towerRadar(tower);
		}
		counterEnemy %= LIMIT;
		counterEnemy++;
	
		if (army != null) {
			army.hasMetThreshold();
		}
	}
	
	public void towerRadar(Tower tower) {

		if (counterEnemy % LIMIT == 0) {
			tower.findEnemy(army);
		}
		if (tower.target != null) {
			// calls attack method
			int index = tower.target.getIndexInArmy();
			if(army.getCritterInArmy(index) != null){
				army.getCritterInArmy(index).inflictDamage(tower.damage);
			}
		}
	}

	public boolean isHasLost() {
		return hasLost;
	}

	public void setHasLost(boolean hasLost) {
		this.hasLost = hasLost;
	}

	public boolean isTowerClicked() {
		return towerClicked;
	}

	public void setTowerClicked(boolean towerClicked) {
		this.towerClicked = towerClicked;
	}
}
