package Controllers;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class CreateMap extends JPanel implements MouseMotionListener, MouseListener{
	
	private Graphics2D g2d;
	public int COL_AMOUNT = 12;
	public int ROW_AMOUNT = 12;
	
	public final static int StartCol = 0;
	public final static int StartRow = 1;
	public int COL_SIZE = Global.WIDTH/COL_AMOUNT;
	public int ROW_SIZE = Global.HEIGHT/ROW_AMOUNT;
	private boolean inCreationMode = false;
	private boolean isOutOfMap = false;
	private boolean isPlacingFirstCell = true;
	private boolean isPlacingSecondCell = false;
	private ArrayList<Integer> path = new ArrayList<Integer>();
	private int prev = 0;
	private int curr = 0;
	private JLabel mapSuccessful;
	private JButton saveMap;
	private JButton playMap;
	private int xMap;
	private int yMap;
	private MainMenu menu;
	private boolean wantsToQuit = false;
	BufferedWriter writer;

	
	public CreateMap(MainMenu menu){
		this.menu = menu;
		this.setLayout(null);
		this.setPreferredSize(new Dimension(Global.WIDTH + 200, Global.HEIGHT));
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		setMenu();
	}
	
	public void paintComponent(Graphics g){
		// Grid Layout
		if (!wantsToQuit) {
			setGrid(g);
			setPath(g);
			setColorToMouse(g);
		}
	}
	
	protected void createMapThread(){
		Thread thread = new Thread(new Runnable(){
			@Override
			public void run() {
				while(!wantsToQuit){
					invalidate();
					repaint();
				}
			}
		});
		thread.start();
	}
	
	public void create(){
		try{
			createMapThread();
		} catch (Exception e){
			
		}
	}
	
	public void setMenu(){
		JLabel options = new JLabel("Modify Map");
		options.setBounds(Global.WIDTH + 50, 10, 100, 30);
		JLabel height = new JLabel("Height");
		height.setBounds(Global.WIDTH + 25, 50, 50, 30);
		final JTextField heightInput = new JTextField();
		heightInput.setBounds(Global.WIDTH + 80, 50, 100, 30);
		
		JLabel width = new JLabel("Width");
		width.setBounds(Global.WIDTH + 25, 90, 50, 30);
		final JTextField widthInput = new JTextField();
		widthInput.setBounds(Global.WIDTH + 80, 90, 100, 30);
		
		JButton applyChanges = new JButton("Apply");
		applyChanges.setBounds(Global.WIDTH + 30, 140, 140, 30);
		applyChanges.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				String heightStr = heightInput.getText().toString();
				String widthStr = widthInput.getText().toString();
				// TODO check that input is only integer
				if(!heightStr.equals("") && !widthStr.equals("")){
					COL_AMOUNT = Integer.parseInt(widthInput.getText()
							.toString());
					ROW_AMOUNT = Integer.parseInt(heightInput.getText()
							.toString());
					COL_SIZE = Global.WIDTH / COL_AMOUNT;
					ROW_SIZE = Global.HEIGHT / ROW_AMOUNT;
					repaint();
				}
			}
		});
		
		JButton createPath = new JButton("Creation Mode");
		createPath.setBounds(Global.WIDTH + 30, 180, 140, 30);
		createPath.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(inCreationMode){
					inCreationMode = false;
				} else {
					inCreationMode = true;
				}
			}
		});
		
		JButton validate = new JButton("Validate");
		validate.setBounds(Global.WIDTH + 30, 220, 140, 30);
		validate.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				inCreationMode = false;
				if(isValidMap()){
					mapSuccessful.setText("Map is valid!");
					saveMap.setVisible(true);
					playMap.setVisible(true);
				} else {
					inCreationMode = true;
				}
			}
			
		});
		
		JButton restart = new JButton("Restart");
		restart.setBounds(Global.WIDTH + 30, 260, 140, 30);
		restart.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				isPlacingFirstCell = true;
				isPlacingSecondCell = false;
				inCreationMode = false;
				path.clear();
				prev = 0;
				curr = 0;
				System.out.println("Hello");
				mapSuccessful.setVisible(false);
				saveMap.setVisible(false);
				playMap.setVisible(false);
			}
			
		});
		
		mapSuccessful = new JLabel("");
		mapSuccessful.setBounds(Global.WIDTH + 30, 300, 140, 30);
		
		final JTextField mapName = new JTextField();
		mapName.setBounds(Global.WIDTH + 30, 350, 140, 30);

		
		saveMap = new JButton("Save Map");
		saveMap.setBounds(Global.WIDTH + 30, 390, 140, 30);
		saveMap.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				saveMapCVS(mapName.getText(),path);
				menu.getComboBox().addItem(mapName.getText());
				wantsToQuit = true;
			}
			
		});
		
		playMap = new JButton("Play Map");
		playMap.setBounds(Global.WIDTH + 30, 430, 140, 30);
		playMap.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				menu.playCustomedMap(path, Global.HEIGHT - Global.HEIGHT % ROW_SIZE, 
						Global.WIDTH - Global.WIDTH % COL_SIZE, COL_AMOUNT,
						ROW_AMOUNT);
			}
			
		});
		
		JButton btnquit = new JButton("Quit");
		btnquit.setBounds(Global.WIDTH + 30, 470, 140, 30);
		btnquit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				menu.goBackToMenuFromCreateMap();

			}
		});
		saveMap.setVisible(false);
		playMap.setVisible(false);
		this.add(playMap);
		this.add(btnquit);
		this.add(mapSuccessful);
		this.add(saveMap);
		this.add(options);
		this.add(height);
		this.add(heightInput);
		this.add(width);
		this.add(widthInput);
		this.add(applyChanges);
		this.add(createPath);
		this.add(validate);
		this.add(restart);
		this.add(mapName);
	}
	public void saveMapCVS(String name, ArrayList<Integer> path){
		   try
		    {
		    File file = new File("./MapsInfo.csv");
		    FileWriter fileWritter = new FileWriter(file,true);

		    writer = new BufferedWriter(fileWritter);
		    writer.newLine();
		    writer.write(name);
		    for(Integer loc : path){
		    	writer.write(","+loc);
		    }
		    writer.flush();
		    writer.close();

		    }
		    catch(FileNotFoundException e)
		    {
		        System.out.println("File Not Found");
		        System.exit( 1 );
		    }
		    catch(IOException e)
		    {
		        System.out.println("something messed up");
		        System.exit( 1 );
		    }
		   
	}
	
	public void setGrid(Graphics g) {
		g2d = (Graphics2D) g;

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, Global.WIDTH + 5, Global.HEIGHT);

		g.setColor(Color.BLACK);
		for (int i = 0; i <= ROW_AMOUNT; i++) {
			if(i == ROW_AMOUNT){
				g2d.drawLine(0, i * ROW_SIZE - 1, Global.WIDTH - 1 - Global.WIDTH % COL_SIZE, i * ROW_SIZE - 1);
				continue;
			}
			g2d.drawLine(0, i * ROW_SIZE, Global.WIDTH-1 - Global.WIDTH % COL_SIZE, i * ROW_SIZE);
		}
		for (int i = 0; i <= COL_AMOUNT; i++) {
			g2d.drawLine(i * COL_SIZE, 0, i * COL_SIZE, Global.HEIGHT -1 - Global.HEIGHT % COL_SIZE);
		}

	}
	
	public void setPath(Graphics g){
		for(int i = 0; i < path.size(); i++){
			int id = path.get(i) - 1;
			g.setColor(Color.CYAN);
			g.fillRect((id % COL_AMOUNT) * COL_SIZE + 1, 
					(id / COL_AMOUNT) * ROW_SIZE + 1,
					COL_SIZE - 1, ROW_SIZE - 1);
		}
	}
	
	private boolean isValidMap(){
		if(path.size() <=2) return false;
		int last = path.get(path.size() - 1);
		if(last <= COL_AMOUNT) return true;
		if(last > COL_AMOUNT * (ROW_AMOUNT - 1)) return true;
		if(last % COL_AMOUNT == 0) return true;
		if((last - 1) % COL_AMOUNT == 0) return true;
		return false;
	}
	
	@Override
	public void mouseClicked(MouseEvent arg0) {
		if (arg0.getX() < Global.WIDTH) {
			int id = getMouseCell(arg0);
			System.out.println(id);
			if (isPlacingFirstCell
					&& (xMap == 0 || xMap == (COL_AMOUNT - 1) * COL_SIZE
							|| yMap == 0 || yMap == (ROW_AMOUNT - 1) * ROW_SIZE)) {
				prev = id;
				path.add(id);
				isPlacingFirstCell = false;
				isPlacingSecondCell = true;
			} else if(isPlacingSecondCell){
				int subs = id - prev;
				if(subs == 1 || subs == -1 || subs == COL_AMOUNT
						|| subs == -COL_AMOUNT){
				curr = id;
				path.add(id);
				isPlacingSecondCell = false;
				}
			} else if (isNextCell(id)) {
				prev = curr;
				curr = id;
				path.add(id);
			}
			for (int i = 0; i < path.size(); i++) {
				System.out.println(path.get(i));
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		getCellXY(e);
	}
	
	public void getCellXY(MouseEvent e) {
		int mouseCell = getMouseCell(e) - 1;

		xMap = (mouseCell % COL_AMOUNT) * COL_SIZE;
		yMap = (mouseCell / COL_AMOUNT) * ROW_SIZE;
	}

	private int getMouseCell(MouseEvent e) {
		int currentX = e.getX();
		int currentY = e.getY();

		if(currentX >= Global.WIDTH) 
			isOutOfMap = true;
		else 
			isOutOfMap = false;

		int tileCol = currentX / COL_SIZE;
		int tileRow = currentY / ROW_SIZE;

		return tileRow * COL_AMOUNT + tileCol + 1;
	}
	
	public void setColorToMouse(Graphics g){
		if (inCreationMode) {
			int id = (yMap / ROW_SIZE) * COL_AMOUNT + (xMap / COL_SIZE + 1);

			if (!isOutOfMap && isPlacingFirstCell) {
				if (xMap == 0 || xMap == (COL_AMOUNT - 1) * COL_SIZE
						|| yMap == 0 || yMap == (ROW_AMOUNT - 1) * ROW_SIZE) {
					g.setColor(Color.YELLOW);
					g.fillRect(xMap + 1, yMap + 1, COL_SIZE - 1, ROW_SIZE - 1);
				}
			} else if (isPlacingSecondCell) {
				int subs = id - prev;
				if (subs == 1 || subs == -1 || subs == COL_AMOUNT
						|| subs == -COL_AMOUNT) {
					g.setColor(Color.YELLOW);
					g.fillRect(xMap + 1, yMap + 1, COL_SIZE - 1, ROW_SIZE - 1);
				}
			} else if (!isOutOfMap && isNextCell(id)) {
				g.setColor(Color.YELLOW);
				g.fillRect(xMap + 1, yMap + 1, COL_SIZE - 1, ROW_SIZE - 1);
			}
		}
	}
	
	public boolean isNextCell(int id){
		if (curr - prev == 1) {
			if (id - curr == -1)
				return false;
			if (id -curr == 1 || id - curr == COL_AMOUNT
					|| id -curr == - COL_AMOUNT) return true;
		} else if (curr - prev == -1) {
			if (id - curr == 1)
				return false;
			if(id - curr == -1 || id - curr == COL_AMOUNT
					|| id -curr == - COL_AMOUNT) return true;
		} else if (curr - prev == COL_AMOUNT) {
			if (id - curr == -COL_AMOUNT)
				return false;
			if(id - curr == COL_AMOUNT || id -curr == 1 
					|| id - curr == -1) return true;
		} else if (curr - prev == -COL_AMOUNT) {
			if (id - curr == COL_AMOUNT)
				return false;
			if(id - curr == - COL_AMOUNT || id -curr == 1 
					|| id - curr == -1) return true;
		}
		return false;
	}
	
}
