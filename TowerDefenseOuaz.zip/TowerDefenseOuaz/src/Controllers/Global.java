package Controllers;

public class Global {
	public final static int COL_AMOUNT = 12;
	public final static int ROW_AMOUNT = 12;
	public final static int OFFSET = 5;
	public final static int HEIGHT = 600;
	public final static int WIDTH = 600;
	
	public static int COL_SIZE = WIDTH/COL_AMOUNT;
	public static int ROW_SIZE = HEIGHT/ROW_AMOUNT;
}
