package Controllers;

import java.util.ArrayList;

import Models.Critter;
import Models.Map;

public class CritterController {
	private ArrayList<Integer> xCritters;
	private ArrayList<Integer> yCritters;
	
	private ArrayList<Critter> army;
	
	private int pointer;
	private int threshold;
	
	private int ColAmountMap;
	private int RowAmountMap;
	private int ColSizeMap;
	private int RowSizeMap;
	private int HeightMap;
	private int WidthMap;
	private Map map;
	
	private int initialDirection;
	
	public CritterController(ArrayList<Critter> army, Map map){
		this.setMap(map);
		this.army = army;
		this.xCritters = setXForArmy(this.army);
		this.yCritters = setYForArmy(this.army);
		this.pointer = 0;
		this.setMap(map);
		this.ColAmountMap = map.getLength();
		this.RowAmountMap = map.getHeight();
		this.ColSizeMap = map.getColSizeMap();
		this.RowSizeMap = map.getRowSizeMap();
		activateSwitch();		
	}
	
	public CritterController(ArrayList<Critter> army, int height, int width, 
			int numCols, int numRows){
		this.ColAmountMap = numCols;
		this.RowAmountMap = numRows;
		this.setHeightMap(height);
		this.setWidthMap(width);
		this.ColSizeMap = width/ColAmountMap;
		this.setRowSizeMap(height/RowAmountMap);
		
		this.army = army;
		this.xCritters = setXForArmy(this.army);
		this.yCritters = setYForArmy(this.army);
		this.pointer = 0;
		activateSwitch();
	}
	
	private ArrayList<Integer> setXForArmy(ArrayList<Critter> army){
		int length = army.size();
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for(int i = 0; i < length; i++){
			temp.add(army.get(i).getxAccumulator() + army.get(i).getxIterator() 
					+ ColSizeMap/2 - Global.OFFSET);
		}
		return temp;
	}
	
	private ArrayList<Integer> setYForArmy(ArrayList<Critter> army){
		int length = army.size();
		ArrayList<Integer> temp = new ArrayList<Integer>();
		for(int i = 0; i < length; i++){
			temp.add(army.get(i).getyAccumulator() + army.get(i).getyIterator() 
					+ ColSizeMap/2 - Global.OFFSET);
		}
		return temp;
	}
	
	public void removeDeadCritters(int index){
		army.remove(index);
		xCritters.remove(index);
		yCritters.remove(index);
		pointer--;
		for(int i = 0; i < army.size(); i++){
			Critter critter = army.get(i);
			critter.setIndexInArmy(i);
		}
	}
	
	public void hasMetThreshold(){
		if(initialDirection == 1 || initialDirection == 3){
			if(pointer != army.size()-1){
				if (xCritters.get(pointer) == threshold) {
					army.get(pointer + 1).reset();
					pointer++;
				}
			}
		} else if(initialDirection == 0 || initialDirection == 2){
			if(pointer != army.size()-1){
				if (yCritters.get(pointer) == threshold) {
					army.get(pointer + 1).reset();
					pointer++;
				}
			}
		}
		for(int i = 0; i <= pointer; i++){
			army.get(i).iterateCritter();
		}
		yCritters = setYForArmy(army);
		xCritters = setXForArmy(army);	
	}
	
	public void activateSwitch(){
		int [] temp = map.getInitialCells();
		int c1 = temp[0];
		int c2 = temp[1];
		int subs = c2 - c1;
		
		if(subs == ColAmountMap){
			initialDirection = 2;
			threshold = map.getRowSizeMap()/2 - Global.OFFSET 
					+ map.getRowSizeMap() * (map.getStartRow() + 1);
		} else if (subs == - ColAmountMap){
			initialDirection = 0;
			threshold = map.getRowSizeMap()/2 - Global.OFFSET 
					+ map.getRowSizeMap() * (map.getStartRow() - 1);
		} else if (subs == 1){
			initialDirection = 3;
			threshold = map.getColSizeMap()/2 - Global.OFFSET 
					+ map.getColSizeMap() * (map.getStartCol() + 1);
		} else if(subs == -1){
			initialDirection = 1;
			threshold = map.getColSizeMap()/2 - Global.OFFSET 
					+ map.getColSizeMap() * (map.getStartCol() - 1);
		}
	}
	
	public int getPointer() {
		return pointer;
	}
	
	public int getLength(){
		return this.army.size();
	}

	public void setPointer(int pointer) {
		this.pointer = pointer;
	}
	
	public Critter getCritterInArmy(int index){
		if(index >= army.size()) return null;
		return army.get(index);
	}
	
	public ArrayList<Critter> getArmy(){
		return army;
	}

	public ArrayList<Integer> getyCritters() {
		return yCritters;
	}

	public void setyCritters(ArrayList<Integer> yCritters) {
		this.yCritters = yCritters;
	}
	
	public ArrayList<Integer> getxCritters() {
		return xCritters;
	}

	public void setxCritters(ArrayList<Integer> xCritters) {
		this.xCritters = xCritters;
	}

	public int getRowSizeMap() {
		return RowSizeMap;
	}

	public void setRowSizeMap(int rowSizeMap) {
		RowSizeMap = rowSizeMap;
	}

	public int getHeightMap() {
		return HeightMap;
	}

	public void setHeightMap(int heightMap) {
		HeightMap = heightMap;
	}

	public int getWidthMap() {
		return WidthMap;
	}

	public void setWidthMap(int widthMap) {
		WidthMap = widthMap;
	}

	public Map getMap() {
		return map;
	}

	public void setMap(Map map) {
		this.map = map;
	}
}
