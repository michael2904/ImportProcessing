package Controllers;

import java.util.ArrayList;

import Models.Tower;

public class TowerController {
	
	private ArrayList<Tower> towers = new ArrayList<Tower>();
	private CritterController army;
	public TowerController(ArrayList<Tower> towers, CritterController army){
		this.towers = towers;
		this.army = army;
	}
	
	public void update(){
		
	}

	public ArrayList<Tower> getTowers() {
		return towers;
	}

	public void setTowers(ArrayList<Tower> towers) {
		this.towers = towers;
	};
	
	public CritterController getArmy(){
		return army;
	}
	
	public void setArmy(CritterController army){
		this.army = army;
	}
	private int counterEnemy = 0;
	private int LIMIT = 40;
	
	public void towerUpdate() {
		if (towers != null) {
			for (int i = 0; i < towers.size(); i++) {
				Tower tower = towers.get(i);
				towerRadar(tower);
			}
			counterEnemy %= LIMIT;
			counterEnemy++;

			if (army != null) {
				army.hasMetThreshold();
			}
		}
	}
	
	public void towerRadar(Tower tower) {

		if (counterEnemy % LIMIT == 0) {
			tower.findEnemy(army);
		}
		if (tower.target != null) {
			// calls attack method
			int index = tower.target.getIndexInArmy();
			if(army.getCritterInArmy(index) != null){
				army.getCritterInArmy(index).inflictDamage(tower.damage);
			}
		}
	}
}
