package Models;

import java.util.ArrayList;

import Controllers.Global;
import Models.Cell.CellType;
import Models.PathCell.PathType;

public class Map {
	// Each map has a start and an end
	private static PathCell start;
	private static PathCell end;
	
	// The map is contained in a grid
	private static Cell [][] container;
	
	//The Path cells are stored in an array and have an unknown length
	private static ArrayList <PathCell> path;
	
	//The parameters of the map
	private static int height;
	private static int length;

	private int ColSizeMap;
	private int RowSizeMap;
	private int HeightMap;
	private int WidthMap;
	
	private int StartCol;
	private int StartRow;
	
	//This code assumes the user will always input a start Tile first!
	public Map(int ROW_AMOUNT, int COL_AMOUNT, int ROW_SIZE, int COL_SIZE, ArrayList<PathCell> path){
		int count = 1;
		this.height = ROW_AMOUNT;
		this.length = COL_AMOUNT;
		this.path = path;
		this.setRowSizeMap(ROW_SIZE);
		this.setColSizeMap(COL_SIZE);
		this.setHeightMap(ROW_AMOUNT * ROW_SIZE);
		this.setWidthMap(COL_AMOUNT * COL_SIZE);
		
		this.StartCol = (path.get(0).getId() - 1) % COL_AMOUNT;
		this.StartRow = (path.get(0).getId() - 1) / COL_AMOUNT;
		
		if(path.size() >= 2){
			this.start = path.get(0);
			this.end = path.get(path.size()-1);
		}
		//The custom map will first be presented to the user as a scenery cell
		//The user will decide if whether or not it wants to keep this way or if it wants to place a path cell
		
		// Setup all the path cells in the map, for map creation
		container = new Cell[height][length];
		int id, row, col;
		for(int i = 0; i < path.size(); i++){
			id = path.get(i).getId();
			row = calcRow(id);
			col = calcCol(id);
			int x = ((id - 1) % COL_AMOUNT) * COL_SIZE;
			int y = ((id - 1) / COL_AMOUNT)* ROW_SIZE;
//			System.out.println("ID:" + id + " row:" + row +
//					" col:" + col + " x:" + x + " y:" + y);
			//This line assumes makes the scenery cell become a path cell
			container[row][col] = path.get(i);
			container[row][col].setRow(row);
			container[row][col].setCol(col);
			container[row][col].setId(id);
			container[row][col].setxCoord(x);
			container[row][col].setyCoord(y);
			
		}
		
		// Fill all the remaining cells as scenery cells
		for(int i = 0; i < height; i++){
			for(int j = 0; j < length; j++){
				if(container[i][j] == null){
					container[i][j] = new SceneryCell(count);
				}
				container[i][j].setCol(j);
				container[i][j].setRow(i);
				container[i][j].setId(count++);
			}
		}

	}
	
	public int [] getInitialCells(){
		int [] temp = new int[2];
		temp[0] = path.get(0).getId();
		temp[1] = path.get(1).getId();
		return temp;
	}
	
	// These methods return the programmatic(0 to length -1) column and row of a cell
	private int calcRow(int id){
		if(id % length == 0) return (id -1)/length;
		return id/length;
	}
	
	private int calcCol(int id){
		if(id % length == 0) return length - 1;
		return id % length - 1;
	}
	
	public Cell[][] getContainer(){
		return container;
	}
	
	public int getHeight(){
		return height;
	}
	
	public int getLength(){
		return length;
	}
	
	public PathCell getStart(){
		return start;
	}
	
	public PathCell getEnd(){
		return end;
	}
	
	public int [] getXYFromId(int id){
		int col = (id-1) % length;
		int row = (id-1) / length;
		int tempX = container[row][col].getxCoord();
		int tempY = container[row][col].getyCoord();
		int [] coords = {tempX,tempY};
		return coords;
	}
	
	// assuming we are counting from 1 to COL_AMOUNT
	public void addTower(int row, int col) {
		if (row <= 0 || row > Global.ROW_AMOUNT) {
			return;
		} else if (col <= 0 || col > Global.COL_AMOUNT) {
			return;
		}
		SceneryCell cell = null;
		if (container[row][col].getCellType() == Cell.CellType.SCENERY) {
			cell = (SceneryCell) container[row][col];
			if (!cell.hasTower()) {
				cell.setHasTower(true);
			}
		}
	}

	public void removeTower(int row, int col) {
		if (row <= 0 || row > Global.ROW_AMOUNT) {
			return;
		} else if (col <= 0 || col > Global.COL_AMOUNT) {
			return;
		}
		System.out.println("HEllo");
		SceneryCell cell = null;
		if (container[row][col].getCellType() == Cell.CellType.SCENERY) {
			cell = (SceneryCell) container[row][col];
			if (cell.hasTower()) {
				System.out.println("Tower removed at row: " + row + " col: " + col);
				cell.setHasTower(false);
			}
		}
	}

	// Check validity of map
	public static boolean isMapValid(Map map){
		// Start cell is a special case since it does not have a previous cell
		PathCell prev = map.getStart();
		prev.setEndArrow(getEnd(prev));
		prev.getStartArrow().setDirection(prev.startofPathCell(prev.getEndArrow().getDirection()));
		int k = 1;
		
		PathCell curr;
		while(k < path.size()){
			// Check if the cell's end corresponds to the previous' cell's start
			prev = path.get(k-1);
			curr = path.get(k);
			
			if(curr.getId() != expectedNextCell(prev.getRow(),prev.getCol())){
				System.out.println("Failed at: " + curr.getId());
				System.out.println(expectedNextCell(prev.getRow(),prev.getCol()));
				return false;
			}
			// Update the value pf the cell's start for next iteration
			curr.setEndArrow(getEnd(curr,prev));
			curr.getStartArrow().setDirection(curr.startofPathCell(curr.getEndArrow().getDirection()));
			k++;
		}
		// Ensure there is one end
		return isValidEnd(path.get(k - 1));
	}
	
	// Calculates what is expected of the next cell in path to see if path is coherent
	public static int expectedNextCell(int row, int col){
		if(row > height - 1 || row < 0) return 0;
		if(col > length - 1 || col < 0) return 0;
		
		PathCell current = (PathCell) container[row][col];
		int id = current.getId();
		int next = 0;
		
		// check what next cell should be based on the type of the path
		// it is either going forward, right or left
		if(current.getCellType() == CellType.PATH){
			switch((current).getStartArrow().getDirection()){
			case 0:
				if(row == 0){
					return 0;
				} else {
					next = id - length;
				}
				break;
			case 1:
				if(col == 0){
					return 0;
				} else {
					next = id -1;
				}
				break;
			case 2:
				if(row == height - 1){
					return 0;
				} else {
					next = id + length;
				}
				break;
			case 3:
				if(col == length - 1){
					return 0;
				} else {
					next = id + 1;
				}
				break;
			}
		}
		return next;
	}
	
	
	public static int getEnd(PathCell cell){
		int id = cell.getId();
		// There must be a method checking for cells starting in the corner
		if(id == 1 || id == length || id == length* height - length +1 || id == length*height){
			return setEndStartCorner(cell);
		} 
		// Check if start cell is in a border and get the orientation of the end arrow of the cell
		else if(cell.getId() < length){
			return 0;
		} else if(cell.getId() % length == 1){
			return 1;
		} else if(cell.getId() % length == 0){
			return 3;
		} else if(cell.getId() > height * length - length){
			return 2;
		} else {
			return 4;
		}
	}
	
	// These are cases in which the cell is in any corner
	public static int setEndStartCorner(PathCell cell) {
		int id = cell.getId();
		PathCell second = path.get(1);
		PathType type = cell.getPathType();
		if (id == 1) {
			if (second.getId() == id + 1) {
				if (type == PathType.FORWARD) {
					return 1;
				} else if (type == PathType.TURN_LEFT) {
					return 0;
				} else
					return 4;
			} else if (second.getId() == id + length) {
				if (type == PathType.FORWARD) {
					return 0;
				} else if (type == PathType.TURN_RIGHT) {
					return 1;
				} else
					return 4;
			} else
				return 4;
		} else if (id == length) {
			if (second.getId() == id - 1) {
				if (type == PathType.FORWARD) {
					return 3;
				} else if (type == PathType.TURN_RIGHT) {
					return 0;
				} else
					return 4;
			} else if (second.getId() == id + length) {
				if (type == PathType.FORWARD) {
					return 0;
				} else if (type == PathType.TURN_LEFT) {
					return 3;
				} else
					return 4;
			} else
				return 4;
		} else if (id == length * height - length + 1) {
			if (second.getId() == id - length) {
				if (type == PathType.FORWARD) {
					return 2;
				} else if (type == PathType.TURN_LEFT) {
					return 1;
				} else
					return 4;
			} else if (second.getId() == id + 1) {
				if (type == PathType.FORWARD) {
					return 1;
				} else if (type == PathType.TURN_RIGHT) {
					return 2;
				} else
					return 4;
			} else
				return 4;
		} else if (id == length * height) {
			if (second.getId() == id - 1) {
				if (type == PathType.FORWARD) {
					return 3;
				} else if (type == PathType.TURN_LEFT) {
					return 2;
				} else
					return 4;
			} else if (second.getId() == id - length) {
				if (type == PathType.FORWARD) {
					return 2;
				} else if (type == PathType.TURN_RIGHT) {
					return 3;
				} else
					return 4;
			} else
				return 4;
		} else
			return 4;
	}
	
	//This method flips at 180 degrees the orientation of the start arrow from
	//the previous cell on path
	public static int getEnd(PathCell cell, PathCell prev){
		int startPrev = prev.getStartArrow().getDirection();
		int end = 4;
		switch(startPrev){
		case 0:
			end = 2;
			break;
		case 1:
			end = 3;
			break;
		case 2:
			end = 0;
			break;
		case 3:
			end = 1;
			break;
		}
		return end;
	}
	
	// Check if last path cell is on border or in a corner
	public static boolean isValidEnd(PathCell cell){
		int id = cell.getId();
		int dir = cell.getStartArrow().getDirection();
		if(id == 0){
			return dir == 0 || dir == 1;
		} else if ( id == length){
			return dir == 0 || dir == 3;
		} else if ( id == length*height - length + 1){
			return dir == 1 || dir == 2;
		} else if(id == height*length){
			return dir == 2 || dir == 3;
		} else if(id < length){
			return dir == 0;
		} else if(id % length == 1){
			return dir == 1;
		} else if(id > height* length - length){
			return dir == 2;
		} else if(id % length == 0){
			return dir == 3;
		} else return false;
	}

	public int getStartCol() {
		return StartCol;
	}

	public void setStartCol(int startCol) {
		StartCol = startCol;
	}

	public int getStartRow() {
		return StartRow;
	}

	public void setStartRow(int startRow) {
		StartRow = startRow;
	}

	public int getColSizeMap() {
		return ColSizeMap;
	}

	public void setColSizeMap(int colSizeMap) {
		ColSizeMap = colSizeMap;
	}

	public int getRowSizeMap() {
		return RowSizeMap;
	}

	public void setRowSizeMap(int rowSizeMap) {
		RowSizeMap = rowSizeMap;
	}

	public int getHeightMap() {
		return HeightMap;
	}

	public void setHeightMap(int heightMap) {
		HeightMap = heightMap;
	}

	public int getWidthMap() {
		return WidthMap;
	}

	public void setWidthMap(int widthMap) {
		WidthMap = widthMap;
	}
}
