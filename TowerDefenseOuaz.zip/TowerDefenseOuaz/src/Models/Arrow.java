package Models;

public class Arrow {
	/*
	 * 0 = NORTH
	 * 1 = WEST
	 * 2 = SOUTH
	 * 3 = EAST
	 */
	private int direction;
	// Each path cell contains an end and start arrow
	private boolean isStart;
	
	public Arrow(int direction, boolean isStart){
		this.direction = direction;
		this.isStart = isStart;
	}
	
	//The directions of arrows are changeable
	public void setDirection(int direction){
		this.direction = direction;
	}
	
	public int getDirection(){
		return direction;
	}
}
