package Models;

import java.util.ArrayList;

import Models.Map;

public class Toro extends Critter{

	public Toro(Map map, ArrayList<Integer> pathInput){
		super(map, pathInput);
		this.setSlowFactor(6);//for the speed at which a critter can move
		this.setType(CritterType.TORO);
		this.setLife(1000);
		this.setPointReward(20);
		this.setMoneyReward(10);
		this.setDamage(10);
		
	}
}
