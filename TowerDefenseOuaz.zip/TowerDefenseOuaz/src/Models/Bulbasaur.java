package Models;

import java.awt.Image;

import Controllers.GameController;

public class Bulbasaur extends Tower {

	public Bulbasaur(int id, int level, int cost,int refundValue, int range, int damage,
			Image image, GameController game) {
		super(id,level, cost, refundValue, range,damage ,image, game);
		
	}

}
