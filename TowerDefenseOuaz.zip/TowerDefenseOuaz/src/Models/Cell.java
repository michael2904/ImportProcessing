package Models;

public abstract class Cell {
	private int id;
	private int row;
	private int col;
	private int xCoord;
	private int yCoord;
	private CellType type;
	private boolean canHostTower;
	private boolean critterCanMove;
	private Cell nextCell;
	
	public enum CellType{
		SCENERY, PATH
	}
	
	public Cell(int id){
		this.id = id;
	}
	
	public void setType(CellType type){
		this.type = type;
	}
	
	public CellType getCellType(){
		return type;
	}
	
	public void setId(int id){
		this.id = id;
	}
	
	public boolean canHostTower(){
		return canHostTower;
	}
	
	public boolean critterCanMove(){
		return critterCanMove;
	}
	
	public void setCanHostTower(boolean canHostTower){
		this.canHostTower = canHostTower;
	}
	
	public void setCritterCanMove(boolean critterCanMove){
		this.critterCanMove = critterCanMove;
	}
	
	public int getId(){
		return id;
	}
	
	public void setRow(int row){
		this.row = row;
	}
	
	public void setCol(int col){
		this.col = col;
	}
	
	public int getRow(){
		return row;
	}
	
	public int getCol(){
		return col;
	}

	public Cell getNextCell() {
		return nextCell;
	}

	public void setNextCell(Cell nextCell) {
		this.nextCell = nextCell;
	}

	public int getxCoord() {
		return xCoord;
	}

	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}

	public int getyCoord() {
		return yCoord;
	}

	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}
}
