package Models;
import java.util.*;
import java.awt.*;

import javax.swing.*;

import Models.Critter;
import Controllers.CritterController;
import Controllers.GameController;
import Controllers.Global;

import java.util.ArrayList;
import java.util.List;


public abstract class Tower implements Cloneable{

	//Attributes shared by the subclasses
	
	public int enemiesKilled;
	protected boolean attacked;
	public Critter target;
	private ArrayList<Integer> targetXCoord = new ArrayList<Integer>();
	private ArrayList<Integer> targetYCoord = new ArrayList<Integer>();
	private ArrayList<Integer> indexOfTarget = new ArrayList<Integer>();
	private int targetIndex;
	private int indexInList;
	
	public String textureFile= "";
	public Image texture;

	public int FIRST=1;//Attack enemy nearest base
	public int RANDOM =2; // attack random enemy
	
	public int attackStrategy= RANDOM;
	public int damage;
	public int attackTime;
	public int attackDelay;
	public int reload;
	
	public int range;
	public int id;
	public int cost;
	public int refundValue;
	public int level;
	public final int maxLevel = 5;
	private int posX;
	private int posY;
	private int xCoord;
	private int yCoord;
	
	private GameController game;
	
	public Tower(int id,int level, int cost,int refundValue, int range,int damage
			, Image texture, GameController game){
		this.texture = texture;
		this.id = id;
		this.cost = cost;
		this.range = range;
		this.damage = damage;
		this.refundValue = refundValue;
		this.level = level;
		this.game = game;
	}

	public int getDamage() {
		return damage;
	}

	public int getRange() {
		return range;
	}

	public int getRefundValue() {
		return refundValue;
	}

	public int getCost() {
		return cost;
	}

	public int getPosX() {
		return posX;
	}

	public int getPosY() {
		return posY;
	}

	// Setter Methods

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public void setRefundValue(int refundValue) {
		this.refundValue = refundValue;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public void setRange(int range) {
		this.range = range;
	}

	public void setPosY(int posY) {
		this.posY = posY;
		this.yCoord = posY * game.getRowSizeMap() + game.getRowSizeMap() / 2;
	}

	public void setPosX(int posX) {
		this.posX = posX;
		this.xCoord = posX * game.getColSizeMap() + game.getColSizeMap() / 2;
	}	
	
	public Object clone(){
		try{
			return super.clone();
		}catch(CloneNotSupportedException e){
			e.printStackTrace();
		}
		return null;
	}
	
	public Tower getTextureFile(String str){
		
		this.textureFile = str;
		this.texture = new ImageIcon("res/" +this.textureFile).getImage();
		return null;
	}
	
	public void findEnemy(CritterController army){
		ArrayList<Critter> crittersInRange = new ArrayList<Critter>();
		int towerX= this.xCoord;
		int towerY= this.yCoord;
		int enemyX;
		int enemyY;
		indexOfTarget.clear();
		targetXCoord.clear();
		targetYCoord.clear();
//		System.out.println("[ARMY_SIZE]: " + army.getLength());
		if (army != null) {
			for (int i = 0; i < army.getLength(); i++) {
				enemyX = army.getxCritters().get(i);
				enemyY = army.getyCritters().get(i);

				int dx1 = Math.abs(enemyX - towerX);
				int dx2 = Math.abs(enemyX + 2 * Global.OFFSET - towerX);
				int dy1 = Math.abs(enemyY - towerY);
				int dy2 = Math.abs(enemyY + 2 * Global.OFFSET - towerY);
				int radius = this.range * this.range;

				if ((dx1 * dx1) + (dy1 * dy1) < radius
						|| (dx1 * dx1) + (dy2 * dy2) < radius
						|| (dx2 * dx2) + (dy1 * dy1) < radius
						|| (dx2 * dx2) + (dy2 * dy2) < radius) {
					crittersInRange.add(army.getCritterInArmy(i));
					targetXCoord.add(enemyX);
					targetYCoord.add(enemyY);
					indexOfTarget.add(i);
				}
			}
			int totalEnemies = crittersInRange.size();

			if (totalEnemies > 0) {
				targetIndex = new Random().nextInt(totalEnemies);
				this.target = army.getCritterInArmy(indexOfTarget
						.get(targetIndex));
			} else {
				this.target = null;
			}
		}
	}
	
	public int getxCoord() {
		return xCoord;
	}

	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}

	public int getyCoord() {
		return yCoord;
	}

	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}
	
	public void setTarget(Critter target){
		this.target = target;
	}
	
	public Critter getTarget(){
		return target;
	}

	public ArrayList<Integer> getIndexOfTarget() {
		return indexOfTarget;
	}

	public void setIndexOfTarget(ArrayList<Integer> indexOfTarget) {
		this.indexOfTarget = indexOfTarget;
	}

	public int getIndexInList() {
		return indexInList;
	}

	public void setIndexInList(int indexInList) {
		this.indexInList = indexInList;
	}
	public int getLevel(){
		return level;
	}
	public int getId(){
		return id;
	}
}