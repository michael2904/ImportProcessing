package Models;

public class SceneryCell extends Cell{	
	
	private boolean hasTower = false;
	// Can host tower, but cannot have critters on it
	public SceneryCell(int id){
		super(id);
		this.setType(CellType.SCENERY);
		setCanHostTower(true);
		setCritterCanMove(false);
	}
	public boolean hasTower() {
		return hasTower;
	}
	public void setHasTower(boolean hasTower) {
		this.hasTower = hasTower;
	}
}

