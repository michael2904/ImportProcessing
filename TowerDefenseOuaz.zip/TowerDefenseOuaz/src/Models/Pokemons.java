package Models;

import javax.swing.ImageIcon;

import Controllers.GameController;
import Controllers.Global;

public class Pokemons {
	private Tower [] pokemons = new Tower[9];
	
	public Pokemons(GameController game){
		this.pokemons[0] = new Bulbasaur(0,1,30, 15,game.getColSizeMap(),2,
				new ImageIcon("res/bulbasaur.jpg").getImage(), game);;
		this.pokemons[1] = new Squirtle(1,1,50,25,game.getColSizeMap(),3,
				new ImageIcon("res/squirtle.jpg").getImage(), game);
		this.pokemons[2] = new Charmender(2,1,80,40,game.getColSizeMap(),5,
				new ImageIcon("res/charmender.jpg").getImage(), game);
		this.pokemons[3] = new Bulbasaur(3,2,150, 75,game.getColSizeMap() * 3/2,5,
				new ImageIcon("res/ivysaur.jpg").getImage(), game);;
		this.pokemons[4] = new Squirtle(4,2,250,125,game.getColSizeMap() *3/2,6,
				new ImageIcon("res/wartortle.jpg").getImage(), game);
		this.pokemons[5] = new Charmender(5,2,400,200,game.getColSizeMap() * 3/2,7,
				new ImageIcon("res/charmeleon.jpg").getImage(), game);
		this.pokemons[6] = new Bulbasaur(6,3,750, 375,game.getColSizeMap() *2,8,
				new ImageIcon("res/venusaur.jpg").getImage(), game);
		this.pokemons[7] = new Squirtle(7,3,1250,625,game.getColSizeMap() *2,10,
				new ImageIcon("res/blastoise.jpg").getImage(), game);
		this.pokemons[8] = new Charmender(8,3,2000,1000,game.getColSizeMap() * 2,3,
				new ImageIcon("res/charizard.jpg").getImage(), game);		
	}
	
	public Tower[] getPokemons(){
		return pokemons;
	}
	
	public void displayPokemon(){
		
	}
}
