//Made by: Michael Abdallah-Minciotti 260585955


package Models;

import java.util.ArrayList;

import Models.Map;

public class Potato extends Critter{

	public Potato(Map map, ArrayList<Integer> pathInput){
		super(map, pathInput);
		this.setSlowFactor(4); //for the speed at which a critter can move
		this.setType(CritterType.POTATO);
		this.setLife(900);
		this.setPointReward(30);
		this.setMoneyReward(20);
		this.setDamage(20);
		
	}
	
}
