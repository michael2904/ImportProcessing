package Models;

public class PathCell extends Cell{
	private int row;
	private int col;
	
	// Each cell contains an end and a start arrow;
	// The arrow end of first path cell starts at START, 
	// and the arrow start of last path cell ends at END   
	private Arrow start = new Arrow(4,true);
	private Arrow end = new Arrow(4,false);
	private PathType type;
	
	// 3 types of movement
	public enum PathType{
		TURN_RIGHT, TURN_LEFT, FORWARD
	}
	
	// Cell that cannot host towers, but that can have critters moving in it
	public PathCell(int id, PathType type){
		super(id);
		this.setType(CellType.PATH);
		this.setPathType(type);
		setCanHostTower(false);
		setCritterCanMove(true);
	}
	
	public PathCell(int id, int x, int y){
		super(id);
		this.setxCoord(x);
		this.setyCoord(y);
		this.setType(CellType.PATH);
		setCanHostTower(false);
		setCritterCanMove(true);
	}
	/*
	 * Accounting that :
	 * 0 = NORTH
	 * 1 = WEST
	 * 2 = SOUTH
	 * 3 = EAST
	 * 
	 * This method translates path types to directions
	 */
	public int startofPathCell(int direction){
		int endDirection = direction;
		if(type == PathType.TURN_LEFT){
			return(endDirection + 3) % 4;
		} else if (type == PathType.TURN_RIGHT){
			return(endDirection + 1) % 4;
		} else if (type == PathType.FORWARD){
			return(endDirection + 2) % 4;
		} return 5;
	}
	
	public void setPathType(PathType type){
		this.type = type;
	}
	
	public PathType getPathType(){
		return type;
	}
	
	public Arrow getStartArrow(){
		return start;
	}
	
	public Arrow getEndArrow(){
		return end;
	}
	
	//This is needed for the first path cell
	public void setEndArrow(int direction){
		end.setDirection(direction);
	}
}
