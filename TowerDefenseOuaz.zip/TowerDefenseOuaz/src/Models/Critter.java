//Made by: Michael Abdallah-Minciotti 260585955


package Models;

import java.util.ArrayList;

import Controllers.Global;
import Models.Cell;
import Models.Map;

public abstract class Critter {
		
	private int life; //level of hitpoints of the critter (health)
	private int damage; //amount of health taken from the user when it arrives at the exit point
	private int moneyReward;
	private int pointReward;
	Cell  curCell; //the current tile where a critter is.
	Map maps; //the map in which the critter is located
	private Boolean alive=true; //gives the status of a critter, dead or alive
	
	private boolean isMovingVertically = false;
	private boolean isMovingPos = false;
	private boolean hasReachedLastCell = false;
	private int xIterator, yIterator, xAccumulator, yAccumulator;
	int speed; //for the speed at which a critter can move
	private int slowFactor;
	
	private int currentIndex, currentDestinationID;
	private int [] path;
	private Map map;
	private int posX;
	private int posY;
	private CritterType type;
	private int indexInArmy;
	
	public enum CritterType{
		TORO, OUAZ, POTATO
	}
	
	public Critter(Map map, ArrayList<Integer> pathInput){
		this.map = map;
		this.path = getPathArray(pathInput);
		
		xIterator = 0;
		yIterator = 0;
		xAccumulator = map.getStartCol()*map.getColSizeMap();
		yAccumulator = map.getStartRow()*map.getRowSizeMap();
		currentIndex = 0;
		currentDestinationID = path[currentIndex];
		speed = 0;
	}
	
	public int [] getPathArray(ArrayList<Integer> pathInput){
		int [] temp = new int[pathInput.size()];
		for(int i = 0; i < pathInput.size(); i++){
			temp[i] = pathInput.get(i);
		}
		return temp;
	}
	
	public void inflictDamage(int damage){
		this.life -= damage;
	}
	// TODO iterate less quickly according to the Critter type
	public void iterateCritter() {
		if (!hasReachedCell()) {
			if (isMovingVertically) {
				if (isMovingPos) {
					yIterator += setIteration(slowFactor);
				} else {
					yIterator -= setIteration(slowFactor);
				}
			} else {
				if (isMovingPos) {
					xIterator += setIteration(slowFactor);
				} else {
					xIterator -= setIteration(slowFactor);
				}
			}
		} else {
			setCritterDirection(currentIndex, currentDestinationID);
			xAccumulator += xIterator;
			yAccumulator += yIterator;
			xIterator = 0;
			yIterator = 0;
		}

	}	
	
	private int setIteration(int divisor){
		if(divisor == 0){
			return 1;
		}
		if(speed % divisor == 0){
			speed++;
			return 1;
		} else {
			speed++;
			return 0;
		}
	}
	
	public void reset(){
		xIterator = 0;
		yIterator = 0;
		xAccumulator = map.getStartCol()*map.getColSizeMap();
		yAccumulator = map.getStartRow()*map.getRowSizeMap();
		currentIndex = 0;
		currentDestinationID = path[currentIndex];
		speed = 0;
	}
	
	public void setCritterDirection(int index, int id) {
		if (currentIndex == path.length - 1) {
			hasReachedLastCell = true;
			return;
		}
		int nextID = path[index + 1];
		int diff = nextID - id;
		if (diff == 1) {
			isMovingPos = true;
			isMovingVertically = false;
		} else if (diff == -1) {
			isMovingPos = false;
			isMovingVertically = false;
		} else if (diff == map.getLength()) {
			isMovingPos = true;
			isMovingVertically = true;
		} else if (diff == -map.getLength()) {
			isMovingPos = false;
			isMovingVertically = true;
		}
		currentDestinationID = path[currentIndex + 1];
		currentIndex++;
		
	}

	public boolean hasReachedCell() {
		int [] xy = map.getXYFromId(currentDestinationID);
		int desiredX = xy[0];
		int desiredY = xy[1];
		if(map.getColSizeMap()/2 + xAccumulator + xIterator - Global.OFFSET == desiredX + map.getColSizeMap()/2 - Global.OFFSET
				&& map.getRowSizeMap()/2 + yAccumulator + yIterator - Global.OFFSET == desiredY + map.getRowSizeMap()/2 - Global.OFFSET){
			return true;
		} else {
			return false;
		}
	}
	
	public Boolean getAlive() {
		return alive;
	}

	public int getxIterator() {
		return xIterator;
	}

	public void setxIterator(int xIterator) {
		this.xIterator = xIterator;
	}

	public int getyIterator() {
		return yIterator;
	}

	public void setyIterator(int yIterator) {
		this.yIterator = yIterator;
	}

	public int getxAccumulator() {
		return xAccumulator;
	}
	
	public void setPosY (int posY){
		this.posY = posY;
	}
	public void setPosX (int posX){
		this.posX = posX;
	}

	public void setxAccumulator(int xAccumulator) {
		this.xAccumulator = xAccumulator;
	}

	public int getyAccumulator() {
		return yAccumulator;
	}
	
	public int getPosX(){
		return posX;
	}
	public int getPosY(){
		return posY;
	}

	public void setyAccumulator(int yAccumulator) {
		this.yAccumulator = yAccumulator;
	}

	public void setAlive(Boolean alive) {
		this.alive = alive;
	}

	public int [] getPath(){
		return path;
	}

	public boolean hasReachedLastCell() {
		return hasReachedLastCell;
	}

	public int getSlowFactor() {
		return slowFactor;
	}

	public void setSlowFactor(int slowFactor) {
		this.slowFactor = slowFactor;
	}

	public CritterType getType() {
		return type;
	}

	public void setType(CritterType type) {
		this.type = type;
	}

	public int getIndexInArmy() {
		return indexInArmy;
	}

	public void setIndexInArmy(int indexInArmy) {
		this.indexInArmy = indexInArmy;
	}

	public int getLife() {
		return life;
	}

	public void setLife(int life) {
		this.life = life;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public int getMoneyReward() {
		return moneyReward;
	}

	public void setMoneyReward(int moneyReward) {
		this.moneyReward = moneyReward;
	}

	public int getPointReward() {
		return pointReward;
	}

	public void setPointReward(int pointReward) {
		this.pointReward = pointReward;
	}
	
}
