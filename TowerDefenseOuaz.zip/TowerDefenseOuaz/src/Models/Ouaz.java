//Made by: Michael Abdallah-Minciotti 260585955


package Models;

import java.util.ArrayList;

import Models.Map;

public class Ouaz extends Critter{


	public Ouaz(Map map, ArrayList<Integer> pathInput){
		super(map,pathInput);
		this.setLife(700);
		this.setSlowFactor(2);
		this.setPointReward(40);
		this.setMoneyReward(30);
		this.setDamage(10);
		this.setType(CritterType.OUAZ);
	}

}